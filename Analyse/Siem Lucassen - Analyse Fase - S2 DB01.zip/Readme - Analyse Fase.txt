
In de eerste sprint heb ik analyse documentatie gemaakt wat betrekking heeft tot:
- Planning & iteraties
- Requirements
 - Functionele
 - Non-Functionele
- Use cases
 - Use case diagram
 - Use case omschrijving
- Schermontwerpen
- Conceptueel model

Ik ben van plan om dit web-based project te maken in ASP.Net Core MVC, Owen heeft mij aangreden om Blazor te gebruiken voor de frontend.
Het fijne aan Blazor lijkt me om interactieve web UI in C# te schrijven i.p.v. JavaScript, ook is het fijn om je bezig te houden met maar een programmeertaal.  
Dit is voor mij nog wel een leuke uitdaging omdat ik nog nooit met aan een web-based project heb gewerkt binnen C#. 

Mijn Repositories voor mijn project Chessinator en Algoritmische opdrachten 
zijn te vinden in de volgende git links:

https://github.com/SiemLuc/S2-SiemLucassen-Chessinator
https://github.com/SiemLuc/S2-SiemLucassen-Algoritmiek
